Evidence for PaperNX v0.12.0-reader.3 at 6cec7a714475d386c6069a1b85a49a951a2e264b. Test text and NROs are original synthetic fixtures. Physical Switch acceptance remains unverified.
