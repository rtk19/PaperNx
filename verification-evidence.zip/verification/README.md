PaperNX 0.13.0, source 4c0c762f2d2ab223c72c5bc1d026ee289442ae34. Screenshots use original generated book/comic fixtures. Physical Switch acceptance remains unverified.
