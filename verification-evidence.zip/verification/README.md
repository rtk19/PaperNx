PaperNX v0.12.0-reader.4, source 9afbc42653b0b59d7521c1f28c809b51e4a3fa75. Screenshots use generated original text. Physical Switch acceptance remains unverified.
