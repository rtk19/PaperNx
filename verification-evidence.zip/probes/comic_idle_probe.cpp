#ifdef USE_FIXED
#include "papernx/comic_pages.hpp"
#else
#include "comic_pages_0172.hpp"
#endif
#include <filesystem>
#include <iostream>
using namespace papernx;
int main(int argc,char **argv) {
 if(argc!=3)return 2;
 namespace fs=std::filesystem;
 const fs::path archive="/tmp/papernx-retention-probe.cbr",held=archive.string()+".held";
 fs::copy_file(argv[1],archive,fs::copy_options::overwrite_existing);
 ComicPages pages;pages.configure({"probe",archive.string()});
 auto read=[&](int page){pages.request(page);bool success=false;auto end=std::chrono::steady_clock::now()+std::chrono::seconds(15);
  while(pages.pending() && std::chrono::steady_clock::now()<end){for(auto &r:pages.take())success=!r.rgb.empty();std::this_thread::sleep_for(std::chrono::milliseconds(2));}return success;};
 if(!read(0))return 3;
 std::this_thread::sleep_for(std::chrono::milliseconds(3200));fs::rename(archive,held);
 bool retained=read(1);pages.stop();fs::remove(held);
 std::cout<<"After 3.2 idle seconds, forward read without pathname: "<<(retained?"retained stream":"archive reopen FAILED")<<std::endl;
 return retained==(std::string(argv[2])=="retained")?0:1;
}
