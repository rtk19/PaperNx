Source: a45a52ffa6a8ddc5a267416c71fbf942cde11f79
Committed-source software/OpenGL/sanitizer tests and Switch build/package receipts. Screenshots use original fixtures. Physical Switch acceptance is unverified.
