Source: 3adf684d249242aea968b8950add947eea66fce4
Actual committed-source tests and Switch build receipts. Original/public test text and artwork only. Desktop timings do not establish Switch FPS. Physical Switch acceptance is UNVERIFIED.
