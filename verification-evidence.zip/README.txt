Source: 64610ca87d85a0934bfbf7daf42d0bc4c1f20407
Actual committed-source tests and Switch build receipts. Original/public test text and artwork only. Desktop timings do not establish Switch FPS. Physical Switch acceptance is UNVERIFIED.
