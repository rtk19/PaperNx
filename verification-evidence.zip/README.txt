Source: 0e97d555660484294f8222eb4623ff41a1cf3276
Fresh metadata, portable, build and packaging checks for v0.11.0-reader.4. Developer: Refael Bar. Reader regression evidence: https://github.com/rtk19/PaperNx/releases/tag/v0.11.0-reader.3 . Physical Switch acceptance remains unverified.
