Source: 34473d348e941e68a40821e2348a88a5ddfb5b5d
Original test artwork. Desktop/native, RAR sanitizers, OpenGL and AArch64/NRO distribution checks passed. Physical Nintendo Switch acceptance remains UNVERIFIED.
