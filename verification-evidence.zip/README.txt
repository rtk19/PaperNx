Source: 7c0691eb55f7f89821300745560db2cfb626f507
Actual committed-source tests and Switch build receipts. Original/public test text and artwork only. Desktop timings do not establish Switch FPS. Physical Switch acceptance is UNVERIFIED.
