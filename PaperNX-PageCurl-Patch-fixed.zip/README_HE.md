# PaperNX — דפדוף אינטראקטיבי 0.9.0-curl.2

גרור את הדף באזור הקריאה. גובה האחיזה והתנועה האנכית משנים את הקיפול.
אפשר לעצור בזמן הגרירה, לחזור לאחור ולשחרר לביטול, או להמשיך/להחליק מהר כדי להשלים דפדוף.
האפקט כולל פרספקטיבה תלת-ממדית, גב דף שקוף חלקית, תאורה וצללים.
מתאים ל-EPUB במצב עמודים ול-PDF במצב Fit to Page.

קוד המקור המעודכן: https://github.com/rtk19/PaperNx
הפצה ו-NRO מוכן: https://github.com/rtk19/PaperNx/releases/tag/v0.9.0-curl.2

להחלה על עותק נקי של המקור, חלץ את קובץ ה-patch לצד תיקיית PaperNx:

```sh
git clone https://github.com/ysfbz/PaperNx.git
cd PaperNx
git checkout fc1612fe7c3fbe9d6cc25d33dccbd3ea1202ae9d
git apply --check ../PaperNX-page-curl.patch
git apply ../PaperNX-page-curl.patch
docker compose build switch
docker compose run --rm switch bash scripts/verify-switch.sh
```

עברו בדיקות SDL אמיתי, OpenGL, יישום ואריזה; נבנה NRO אמיתי ל-AArch64.
לא בוצעה בדיקה על חומרת Switch. גבה את הנתונים והחלף רק את sdmc:/switch/PaperNX/PaperNX.nro.
רישיון AGPL-3.0; הודעות רישוי התלויות מצורפות להפצה.
