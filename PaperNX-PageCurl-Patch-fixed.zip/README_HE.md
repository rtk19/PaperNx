# PaperNX — תיקון דפדוף מעודכן

גרסה 0.9.0-curl.1. זוהי חבילת קוד; קובץ NRO מוכן נמצא בגרסת ההפצה בפורק rtk19/PaperNx.

לתיקון עותק נקי של המקור:

```sh
git clone https://github.com/ysfbz/PaperNx.git
cd PaperNx
git checkout fc1612fe7c3fbe9d6cc25d33dccbd3ea1202ae9d
git apply --check ../PaperNX-page-curl.patch
git apply ../PaperNX-page-curl.patch
docker compose build switch
docker compose run --rm switch bash scripts/verify-switch.sh
```

חלץ קודם את קובץ ה-patch מה-ZIP לצד תיקיית המאגר. אפשר גם לשכפל ישירות את https://github.com/rtk19/PaperNx.

התיקון כולל השלמת קיפול רציפה, תור ללחיצות, טקסטורות עצמאיות, תמיכה בגדלי עמודי PDF שונים ושחזור מצב הרינדור. מתאים ל-EPUB במצב עמודים ול-PDF במצב Fit to Page.

עברו בדיקות SDL אמיתי ובדיקות יישום, ונבנה NRO אמיתי ל-AArch64. לא בוצעה בדיקה על חומרת Switch. להתקנה יש לגבות את הנתונים ולהחליף רק את sdmc:/switch/PaperNX/PaperNX.nro.

רישיון AGPL-3.0; קוד המקור והודעות הרישוי זמינים בפורק ובגרסת ההפצה.
